#!/usr/bin/env python3
import subprocess,sys,os
os.environ.update(TEXMFROOT="/usr/share/texlive",TEXMFDIST="/usr/share/texlive/texmf-dist",TEXMF="{/usr/share/texlive/texmf-dist,/usr/share/texmf}",TEXMFCNF="/usr/share/texlive/texmf-dist/web2c",TEXFORMATS="/workspace/scratch/60069f31f8f7/torricelli-publicacion:")
if '--version' in sys.argv:
    sys.exit(subprocess.call(['pdflatex','--version']))
a=sys.argv
cmd=['pdflatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory',a[a.index('--outdir')+1],a[-1]]
for _ in range(2):
    result=subprocess.call(cmd)
    if result: sys.exit(result)
sys.exit(0)
